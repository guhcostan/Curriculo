#include "clip-rectangle.h"
#include <iostream>
#include <cmath>

using namespace std;

const int TOP = 8;
const int BOTTOM = 4;
const int LEFT = 1;
const int RIGHT = 2;
const int INSIDE = 0;

ClipRectangle::ClipRectangle (double xmin, double xmax, double ymin, double ymax)
    : mXmin(xmin), mXmax(xmax), mYmin(ymin), mYmax(ymax), mInitialized(true)
{}

void ClipRectangle::Set(double xmin, double xmax, double ymin, double ymax)
{
    mXmin = xmin;
    mXmax = xmax;
    mYmin = ymin;
    mYmax = ymax;
    mInitialized = true;
}

int ClipRectangle::ClassificaPonto(Point ponto){
	
	int binario = 0;
	if(ponto.mX < mXmin) 
		binario = binario + LEFT;
	if(ponto.mX > mXmax)
		binario = binario + RIGHT;
	if(ponto.mY < mYmin)
		binario = binario + BOTTOM;
	if(ponto.mY > mYmax)
		binario = binario + TOP;
		
	return (binario);
}

// Retorna um ponteiro para uma linha recem alocada inteiramente dentro da area de recorte
// ou NULL se l for comPletamente descartada.
// A linha alocada precisa ser desalocada depois do uso.
Line* ClipRectangle::Clip(const Line& l)
{
	int binarioP0 = ClassificaPonto(l.mP0);
	int binarioP1 = ClassificaPonto(l.mP1);

	Line* segReta = new Line(l.mP0,l.mP1);
	
	while(true){

		if(!(binarioP0|binarioP1)){
			return segReta;
		}
		else if (binarioP0 & binarioP1){
			return (NULL);
		}
		else{
			//Variáveis para guardar pontos de intersecção
			double x,y;
			
			int binario = binarioP0 ? binarioP0 : binarioP1;
			
			if (binario & TOP){
				x = segReta->mP0.mX + (segReta->mP1.mX - segReta->mP0.mX) * (mYmax - segReta->mP0.mY) / (segReta->mP1.mY - segReta->mP0.mY);
				y = mYmax;
			}
			else if(binario & BOTTOM){
				x = segReta->mP0.mX + (segReta->mP1.mX - segReta->mP0.mX) * (mYmin - segReta->mP0.mY) / (segReta->mP1.mY - segReta->mP0.mY);
				y = mYmin;
			}
			else if(binario & RIGHT){
				y = segReta->mP0.mY + (segReta->mP1.mY - segReta->mP0.mY) * (mXmax - segReta->mP0.mX) / (segReta->mP1.mX - segReta->mP0.mX);
				x = mXmax;
			}
			else if(binario & LEFT){
				y = segReta->mP0.mY + (segReta->mP1.mY - segReta->mP0.mY) * (mXmin - segReta->mP0.mX) / (segReta->mP1.mX - segReta->mP0.mX);
				x = mXmin;
			}

			if(binario == binarioP0){
				segReta->mP0.mX = x;
				segReta->mP0.mY = y;
				binarioP0 = ClassificaPonto(segReta->mP0);
			}
			else{
				segReta->mP1.mX = x;
				segReta->mP1.mY = y;
				binarioP1 = ClassificaPonto(segReta->mP1);
			}
			
		}   

	}
}



void ClipRectangle::Read(const string& promPt)
{
    cout << promPt;
    cin >> mXmin >> mXmax >> mYmin >> mYmax;
    mInitialized = true;
}

ostream& operator << (ostream& os, const ClipRectangle& r)
{
    return os << "(Clipping Rectangle: " << r.mXmin << ", " << r.mXmax << ", " 
              << r.mYmin << ", " << r.mYmax << ")";
}

